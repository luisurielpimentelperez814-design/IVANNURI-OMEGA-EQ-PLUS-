import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ivannuri.omega',
  appName: 'IVANNURI OMEGA',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
