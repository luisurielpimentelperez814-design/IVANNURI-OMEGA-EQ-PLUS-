# Guía Oficial de Integración TIDAL para Android (Termux)

Esta guía detalla cómo integrar los recursos oficiales de TIDAL en un proyecto Capacitor/React usando Termux en Android.

## 1. Requisitos de Entorno en Termux
Ejecuta los siguientes comandos para preparar tu entorno con Node.js 24 y herramientas de Android.

```bash
pkg update && pkg upgrade
pkg install nodejs android-tools git
```

## 2. Bibliotecas Oficiales (SDK/API)
TIDAL utiliza paquetes en NPM bajo el scope `@tidal-music`.

### Instalación de Dependencias
```bash
npm install @tidal-music/auth @tidal-music/player-web
```
*Nota: Estas bibliotecas son compatibles con Node.js 24.*

### Repositorios Oficiales y Documentación
- **Portal de Desarrolladores:** [developer.tidal.com](https://developer.tidal.com)
- **SDK Web (GitHub):** [github.com/tidal-music/tidal-sdk-web](https://github.com/tidal-music/tidal-sdk-web)
- **Maven (SDK Nativo Android):** `com.tidal:player-sdk:1.x.x`

## 3. Integración en Capacitor (Android)
Para que Capacitor pueda manejar la autenticación y reproducción en Android, debes sincronizar los archivos:

```bash
# Sincronizar plugins y web assets
npx cap sync android
```

### Soporte de Playback Capture
Para capturar audio de TIDAL (Interceptar audio), Android requiere permisos de `MediaProjection`.
1. El proyecto ya incluye un motor de audio en `src/lib/audioEngine.ts` que utiliza `getDisplayMedia`.
2. Para una integración profunda en Android (Root/System), se recomienda el uso de módulos nativos que implementen `AudioPlaybackCaptureConfiguration`.

## 4. Versiones Recomendadas
- **Node.js:** 24.x
- **Android SDK:** API 34 (Android 14) o superior.
- **Capacitor:** 6.x o superior.

## 5. Ejemplo de Implementación (React)
```typescript
import { TidalService } from './services/tidalService';

const tidal = new TidalService(CLIENT_ID);
// Usar el flujo PKCE para obtener el Access Token
```
