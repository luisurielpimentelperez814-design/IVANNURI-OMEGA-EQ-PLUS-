# IVANNURI OMEGA EQ — Mobile Edition

Este proyecto es un procesador de audio avanzado optimizado para ejecución en dispositivos móviles mediante Capacitor.

## 🚀 Requisitos para Android

1. **Node.js** (v18 o superior).
2. **Android Studio** instalado y configurado.
3. **Android SDK** y **Gradle**.

## 🛠️ Instrucciones de Instalación y Build

### 1. Clonar e Instalar Dependencias
```bash
npm install
```

### 2. Generar el Build de Producción Web
```bash
npm run build
```

### 3. Preparar Entorno Android (Primera vez)
```bash
npx cap add android
```

### 4. Sincronizar Código y Assets
Cada vez que realices cambios en el código de React:
```bash
npm run mobile:build
```

### 5. Abrir en Android Studio para Compilar APK
```bash
npx cap open android
```
- En Android Studio, selecciona `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
- El APK generado estará listo para instalarse en cualquier dispositivo Android.

## 🔐 Configuración de API Keys

Si el proyecto requiere integración con Gemini AI u otros servicios:
- Crea un archivo `.env` basado en `.env.example`.
- **IMPORTANTE:** Nunca subas el archivo `.env` a repositorios públicos.

## ⚖️ Licencia

Este software está bajo una **Licencia Propietaria**. Queda prohibida la modificación, redistribución o venta sin la autorización expresa del autor (ver archivo `LICENSE`).

---
**IVANNURI OMEGA EQ** - *Uncompromised Audio Processing.*
